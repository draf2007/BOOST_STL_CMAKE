#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include <cctype>
#include <map>
#include <fstream>
#include <stdexcept>
#include <set>
#include <algorithm>
#include <utility>
#include <boost/program_options.hpp>

namespace po = boost::program_options;

std::string readFile(const std::string& read_filename){
    std::ifstream file(read_filename);
    if(!file.is_open()){ throw std::runtime_error("Не удалось открыть файл!"); }

    std::string content;
    std::string line;
    while (std::getline(file,line))
    {
        content += line;
        content += ' ';
    }
    return content;
}

std::set<std::string> readBlackList(const std::string& str_blacklist_filename) {
    std::ifstream file(str_blacklist_filename);  

    if (!file.is_open()) {
        throw std::runtime_error("Не удалось открыть файл стоп-слов: " + str_blacklist_filename);
    }

    std::set<std::string> blacklist;
    std::string word;

    while (std::getline(file, word)) {

        if (!word.empty() && word.back() == '\r') {
            word.pop_back();
        }

        if (!word.empty()) {
            blacklist.insert(word);
        }
    }

    return blacklist;
}

std::string toLower(const std::string& word){
    std::string result = word;
    for (char& c : result)
    {
        c = std::tolower(static_cast<unsigned char>(c));
    }
    return result;
    
}

bool isDelimiter(char c) {
    unsigned char uc = static_cast<unsigned char>(c);
    return std::isspace(uc) || std::ispunct(uc);
}

std::vector<std::string> cut_str_to_words(const std::string& text) {
    std::vector<std::string> words;
    std::string current_word;
    for (char c : text) {
        if (isDelimiter(c)) {
            if (!current_word.empty()) {
                words.push_back(toLower(current_word));
                current_word.clear();  
            }
            
        } else {
            
            current_word += c;
        }
    }
    if (!current_word.empty()) {
        words.push_back(toLower(current_word));
    }

    return words;
}

std::vector<std::string> filterBlackList(const std::vector<std::string>& v_words, const std::set<std::string>& s_blackList){
    std::vector<std::string> result;

    for (const auto& word : v_words)
    {
        if (!s_blackList.contains(word))
        {
            result.push_back(word);
        }
        
    }
    return result;
}

std::map<std::string, int> countWord(const std::vector<std::string>& word){

    std::map<std::string, int> freq;
    for (const auto& f_word : word)
    {
        freq[f_word]++;
    }
    return freq;
}

std::vector<std::pair<std::string,int>> sortByFreq(const std::map<std::string, int>& freq){

    std::vector<std::pair<std::string,int>> result(freq.begin(), freq.end());

    std::sort(result.begin(),result.end(),[](const auto& a, const auto& b){ return a.second > b.second; });

    return result;
}


void writeToFile(const std::vector<std::pair<std::string, int>>& v_sorted,
                 const std::string& filename)
{
    std::ofstream file(filename);

    if (!file.is_open()) {
        throw std::runtime_error("Не удалось создать файл: " + filename);
    }

    file << "=== Статистика частоты слов ===\n";
    file << "Уникальных слов: " << v_sorted.size() << "\n";
    file << "--------------------------------\n";

    for (const auto& [word, count] : v_sorted) {
        file << word << ": " << count << "\n";
    }
}

#ifndef WORDFREQ_TESTS
int main(int argc, char* argv[]) {
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    
    po::options_description desc("Доступные параметры");
    desc.add_options()
        ("help,h", "Показать эту справку")
        ("input,i", po::value<std::string>()->default_value("sample.txt"),
            "Входной текстовый файл")
        ("output,o", po::value<std::string>()->default_value("output.txt"),
            "Выходной файл со статистикой")
        ("stopwords,s", po::value<std::string>()->default_value("blacklist.txt"),
            "Файл Blacklist");

    po::variables_map vm;
        try {
            po::store(po::parse_command_line(argc, argv, desc), vm);
            po::notify(vm);
        } catch (const std::exception& ex) {
            std::cout << "Ошибка параметров: " << ex.what() << std::endl;
            std::cout << desc << std::endl;
            return 1;
        }

    if (vm.count("help")) {
        std::cout << desc << std::endl;
        return 0;
    }

    std::string inputFile     = vm["input"].as<std::string>();
    std::string outputFile    = vm["output"].as<std::string>();
    std::string stopwordsFile = vm["stopwords"].as<std::string>();

    std::cout << "Входной файл:   " << inputFile << std::endl;
    std::cout << "Выходной файл:  " << outputFile << std::endl;
    std::cout << "Файл стоп-слов: " << stopwordsFile << std::endl;
    std::cout << std::endl;

    std::string text;
    try {
        text = readFile(inputFile);
    } catch (const std::exception& ex) {
        std::cout << "Ошибка: " << ex.what() << std::endl;
        return 1;
    }

    std::cout << "Прочитано символов: " << text.size() << std::endl;

    std::vector<std::string> words = cut_str_to_words(text);
    std::cout << "Слов всего: " << words.size() << std::endl;

    std::set<std::string> stopWords;
        try {
           stopWords = readBlackList(stopwordsFile);
            } catch (const std::exception& ex) {
    std::cout << "Ошибка: " << ex.what() << std::endl;
            return 1;
            }
    std::cout << "Загружено стоп-слов: " << stopWords.size() << "\n";

    std::vector<std::string> filtered = filterBlackList(words, stopWords);
    std::cout << "Слов после фильтрации: " << filtered.size() << std::endl;

    auto freq = countWord(filtered);
    std::cout << "Уникальных слов: " << freq.size() << std::endl;

    for (const auto& [word, count] : freq) {
        std::cout << word << ": " << count << std::endl;
    }
    
    std::cout<<std::endl;

    auto topWord = sortByFreq(freq);

    std::cout << "Сортировка по частоте: " << std::endl;
    for (const auto& [word, count] : topWord)
    {
        std::cout << word <<": "<< count << std::endl;
    }

    try {
        writeToFile(topWord, outputFile);
        std::cout << "\nРезультат записан в output.txt\n";
    } catch (const std::exception& ex) {
        std::cout << "Ошибка записи: " << ex.what() << std::endl;
    }
    return 0;
}
#endif